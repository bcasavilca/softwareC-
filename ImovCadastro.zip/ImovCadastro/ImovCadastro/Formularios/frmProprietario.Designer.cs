﻿namespace ImovCadastro
{
    partial class frmProprietario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_Detalhes = new System.Windows.Forms.Panel();
            this.cbox_Juridica = new System.Windows.Forms.CheckBox();
            this.tbox_codProprietario = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.tbox_dtProprietario = new System.Windows.Forms.MaskedTextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.tbox_telProprietario = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.tbox_celProprietario = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tbox_emaProprietario = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tbox_cepProprietario = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tbox_ufProprietario = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tbox_baiProprietario = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbox_endProprietario = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbox_cpfProprietario = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbox_rgProprietario = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbox_nmProprietario = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_Alterar = new System.Windows.Forms.Button();
            this.pnl_Lista = new System.Windows.Forms.Panel();
            this.lbox_objProprietario = new System.Windows.Forms.ListBox();
            this.label12 = new System.Windows.Forms.Label();
            this.pnl_Titulo = new System.Windows.Forms.Panel();
            this.pnl_Botoes = new System.Windows.Forms.Panel();
            this.btn_Excluir = new System.Windows.Forms.Button();
            this.btn_Novo = new System.Windows.Forms.Button();
            this.btn_Confirmar = new System.Windows.Forms.Button();
            this.btn_Cancelar = new System.Windows.Forms.Button();
            this.pnl_Detalhes.SuspendLayout();
            this.pnl_Lista.SuspendLayout();
            this.pnl_Botoes.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_Detalhes
            // 
            this.pnl_Detalhes.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.pnl_Detalhes.Controls.Add(this.cbox_Juridica);
            this.pnl_Detalhes.Controls.Add(this.tbox_codProprietario);
            this.pnl_Detalhes.Controls.Add(this.label13);
            this.pnl_Detalhes.Controls.Add(this.tbox_dtProprietario);
            this.pnl_Detalhes.Controls.Add(this.label11);
            this.pnl_Detalhes.Controls.Add(this.tbox_telProprietario);
            this.pnl_Detalhes.Controls.Add(this.label10);
            this.pnl_Detalhes.Controls.Add(this.tbox_celProprietario);
            this.pnl_Detalhes.Controls.Add(this.label9);
            this.pnl_Detalhes.Controls.Add(this.tbox_emaProprietario);
            this.pnl_Detalhes.Controls.Add(this.label8);
            this.pnl_Detalhes.Controls.Add(this.tbox_cepProprietario);
            this.pnl_Detalhes.Controls.Add(this.label7);
            this.pnl_Detalhes.Controls.Add(this.tbox_ufProprietario);
            this.pnl_Detalhes.Controls.Add(this.label6);
            this.pnl_Detalhes.Controls.Add(this.tbox_baiProprietario);
            this.pnl_Detalhes.Controls.Add(this.label5);
            this.pnl_Detalhes.Controls.Add(this.tbox_endProprietario);
            this.pnl_Detalhes.Controls.Add(this.label4);
            this.pnl_Detalhes.Controls.Add(this.tbox_cpfProprietario);
            this.pnl_Detalhes.Controls.Add(this.label3);
            this.pnl_Detalhes.Controls.Add(this.tbox_rgProprietario);
            this.pnl_Detalhes.Controls.Add(this.label2);
            this.pnl_Detalhes.Controls.Add(this.tbox_nmProprietario);
            this.pnl_Detalhes.Controls.Add(this.label1);
            this.pnl_Detalhes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_Detalhes.Location = new System.Drawing.Point(200, 66);
            this.pnl_Detalhes.Name = "pnl_Detalhes";
            this.pnl_Detalhes.Size = new System.Drawing.Size(549, 301);
            this.pnl_Detalhes.TabIndex = 0;
            // 
            // cbox_Juridica
            // 
            this.cbox_Juridica.AutoSize = true;
            this.cbox_Juridica.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbox_Juridica.Location = new System.Drawing.Point(232, 83);
            this.cbox_Juridica.Name = "cbox_Juridica";
            this.cbox_Juridica.Size = new System.Drawing.Size(139, 24);
            this.cbox_Juridica.TabIndex = 27;
            this.cbox_Juridica.Text = "Pessoa Juridica";
            this.cbox_Juridica.UseVisualStyleBackColor = true;
            // 
            // tbox_codProprietario
            // 
            this.tbox_codProprietario.Enabled = false;
            this.tbox_codProprietario.Location = new System.Drawing.Point(91, 266);
            this.tbox_codProprietario.Name = "tbox_codProprietario";
            this.tbox_codProprietario.Size = new System.Drawing.Size(45, 20);
            this.tbox_codProprietario.TabIndex = 26;
            this.tbox_codProprietario.Tag = "1";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(34, 266);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(42, 20);
            this.label13.TabIndex = 25;
            this.label13.Text = "Cod.";
            // 
            // tbox_dtProprietario
            // 
            this.tbox_dtProprietario.Location = new System.Drawing.Point(388, 41);
            this.tbox_dtProprietario.Mask = "00/00/0000";
            this.tbox_dtProprietario.Name = "tbox_dtProprietario";
            this.tbox_dtProprietario.Size = new System.Drawing.Size(100, 20);
            this.tbox_dtProprietario.TabIndex = 8;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(228, 41);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(154, 20);
            this.label11.TabIndex = 20;
            this.label11.Text = "Data de Nascimento";
            // 
            // tbox_telProprietario
            // 
            this.tbox_telProprietario.Location = new System.Drawing.Point(282, 234);
            this.tbox_telProprietario.Name = "tbox_telProprietario";
            this.tbox_telProprietario.Size = new System.Drawing.Size(100, 20);
            this.tbox_telProprietario.TabIndex = 12;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(225, 234);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(30, 20);
            this.label10.TabIndex = 18;
            this.label10.Text = "Tel";
            // 
            // tbox_celProprietario
            // 
            this.tbox_celProprietario.Location = new System.Drawing.Point(282, 201);
            this.tbox_celProprietario.Name = "tbox_celProprietario";
            this.tbox_celProprietario.Size = new System.Drawing.Size(100, 20);
            this.tbox_celProprietario.TabIndex = 11;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(225, 201);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(58, 20);
            this.label9.TabIndex = 16;
            this.label9.Text = "Celular";
            // 
            // tbox_emaProprietario
            // 
            this.tbox_emaProprietario.Location = new System.Drawing.Point(285, 163);
            this.tbox_emaProprietario.Name = "tbox_emaProprietario";
            this.tbox_emaProprietario.Size = new System.Drawing.Size(100, 20);
            this.tbox_emaProprietario.TabIndex = 10;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(228, 163);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(48, 20);
            this.label8.TabIndex = 14;
            this.label8.Text = "Email";
            // 
            // tbox_cepProprietario
            // 
            this.tbox_cepProprietario.Location = new System.Drawing.Point(91, 233);
            this.tbox_cepProprietario.Name = "tbox_cepProprietario";
            this.tbox_cepProprietario.Size = new System.Drawing.Size(100, 20);
            this.tbox_cepProprietario.TabIndex = 7;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(34, 233);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 20);
            this.label7.TabIndex = 12;
            this.label7.Text = "CEP";
            // 
            // tbox_ufProprietario
            // 
            this.tbox_ufProprietario.Location = new System.Drawing.Point(91, 197);
            this.tbox_ufProprietario.Name = "tbox_ufProprietario";
            this.tbox_ufProprietario.Size = new System.Drawing.Size(100, 20);
            this.tbox_ufProprietario.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(34, 197);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(31, 20);
            this.label6.TabIndex = 10;
            this.label6.Text = "UF";
            // 
            // tbox_baiProprietario
            // 
            this.tbox_baiProprietario.Location = new System.Drawing.Point(91, 163);
            this.tbox_baiProprietario.Name = "tbox_baiProprietario";
            this.tbox_baiProprietario.Size = new System.Drawing.Size(100, 20);
            this.tbox_baiProprietario.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(34, 163);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 20);
            this.label5.TabIndex = 8;
            this.label5.Text = "Bairro";
            // 
            // tbox_endProprietario
            // 
            this.tbox_endProprietario.Location = new System.Drawing.Point(144, 134);
            this.tbox_endProprietario.Name = "tbox_endProprietario";
            this.tbox_endProprietario.Size = new System.Drawing.Size(360, 20);
            this.tbox_endProprietario.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(34, 134);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "Endereço";
            // 
            // tbox_cpfProprietario
            // 
            this.tbox_cpfProprietario.Location = new System.Drawing.Point(91, 104);
            this.tbox_cpfProprietario.Name = "tbox_cpfProprietario";
            this.tbox_cpfProprietario.Size = new System.Drawing.Size(100, 20);
            this.tbox_cpfProprietario.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(34, 104);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "CPF";
            // 
            // tbox_rgProprietario
            // 
            this.tbox_rgProprietario.Location = new System.Drawing.Point(91, 71);
            this.tbox_rgProprietario.Name = "tbox_rgProprietario";
            this.tbox_rgProprietario.Size = new System.Drawing.Size(100, 20);
            this.tbox_rgProprietario.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(34, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "RG";
            // 
            // tbox_nmProprietario
            // 
            this.tbox_nmProprietario.Location = new System.Drawing.Point(91, 41);
            this.tbox_nmProprietario.Name = "tbox_nmProprietario";
            this.tbox_nmProprietario.Size = new System.Drawing.Size(100, 20);
            this.tbox_nmProprietario.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(34, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nome";
            // 
            // btn_Alterar
            // 
            this.btn_Alterar.Location = new System.Drawing.Point(109, 6);
            this.btn_Alterar.Name = "btn_Alterar";
            this.btn_Alterar.Size = new System.Drawing.Size(100, 37);
            this.btn_Alterar.TabIndex = 14;
            this.btn_Alterar.Text = "ALTERAR";
            this.btn_Alterar.UseVisualStyleBackColor = true;
            this.btn_Alterar.Click += new System.EventHandler(this.btn_Alterar_Click);
            // 
            // pnl_Lista
            // 
            this.pnl_Lista.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pnl_Lista.Controls.Add(this.lbox_objProprietario);
            this.pnl_Lista.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnl_Lista.Location = new System.Drawing.Point(0, 66);
            this.pnl_Lista.Name = "pnl_Lista";
            this.pnl_Lista.Size = new System.Drawing.Size(200, 301);
            this.pnl_Lista.TabIndex = 66;
            // 
            // lbox_objProprietario
            // 
            this.lbox_objProprietario.FormattingEnabled = true;
            this.lbox_objProprietario.Location = new System.Drawing.Point(0, 6);
            this.lbox_objProprietario.Name = "lbox_objProprietario";
            this.lbox_objProprietario.Size = new System.Drawing.Size(200, 290);
            this.lbox_objProprietario.TabIndex = 0;
            this.lbox_objProprietario.DoubleClick += new System.EventHandler(this.lbox_objProprietarios_DoubleClick);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(228, 1);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(272, 55);
            this.label12.TabIndex = 67;
            this.label12.Text = "Proprietário";
            // 
            // pnl_Titulo
            // 
            this.pnl_Titulo.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pnl_Titulo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_Titulo.Location = new System.Drawing.Point(0, 0);
            this.pnl_Titulo.Name = "pnl_Titulo";
            this.pnl_Titulo.Size = new System.Drawing.Size(749, 66);
            this.pnl_Titulo.TabIndex = 69;
            // 
            // pnl_Botoes
            // 
            this.pnl_Botoes.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pnl_Botoes.Controls.Add(this.btn_Excluir);
            this.pnl_Botoes.Controls.Add(this.btn_Novo);
            this.pnl_Botoes.Controls.Add(this.btn_Confirmar);
            this.pnl_Botoes.Controls.Add(this.btn_Cancelar);
            this.pnl_Botoes.Controls.Add(this.btn_Alterar);
            this.pnl_Botoes.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnl_Botoes.Location = new System.Drawing.Point(0, 367);
            this.pnl_Botoes.Name = "pnl_Botoes";
            this.pnl_Botoes.Size = new System.Drawing.Size(749, 59);
            this.pnl_Botoes.TabIndex = 70;
            // 
            // btn_Excluir
            // 
            this.btn_Excluir.Location = new System.Drawing.Point(215, 6);
            this.btn_Excluir.Name = "btn_Excluir";
            this.btn_Excluir.Size = new System.Drawing.Size(100, 37);
            this.btn_Excluir.TabIndex = 15;
            this.btn_Excluir.Text = "EXCLUIR";
            this.btn_Excluir.UseVisualStyleBackColor = true;
            this.btn_Excluir.Click += new System.EventHandler(this.btn_Excluir_Click);
            // 
            // btn_Novo
            // 
            this.btn_Novo.Location = new System.Drawing.Point(3, 6);
            this.btn_Novo.Name = "btn_Novo";
            this.btn_Novo.Size = new System.Drawing.Size(100, 37);
            this.btn_Novo.TabIndex = 13;
            this.btn_Novo.Text = "NOVO";
            this.btn_Novo.UseVisualStyleBackColor = true;
            this.btn_Novo.Click += new System.EventHandler(this.btn_Novo_Click);
            // 
            // btn_Confirmar
            // 
            this.btn_Confirmar.Location = new System.Drawing.Point(637, 6);
            this.btn_Confirmar.Name = "btn_Confirmar";
            this.btn_Confirmar.Size = new System.Drawing.Size(100, 37);
            this.btn_Confirmar.TabIndex = 17;
            this.btn_Confirmar.Text = "CONFIRMAR";
            this.btn_Confirmar.UseVisualStyleBackColor = true;
            this.btn_Confirmar.Click += new System.EventHandler(this.btn_Confirmar_Click);
            // 
            // btn_Cancelar
            // 
            this.btn_Cancelar.Location = new System.Drawing.Point(522, 6);
            this.btn_Cancelar.Name = "btn_Cancelar";
            this.btn_Cancelar.Size = new System.Drawing.Size(100, 37);
            this.btn_Cancelar.TabIndex = 16;
            this.btn_Cancelar.Text = "CANCELAR";
            this.btn_Cancelar.UseVisualStyleBackColor = true;
            this.btn_Cancelar.Click += new System.EventHandler(this.btn_Cancelar_Click);
            // 
            // frmProprietario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(749, 426);
            this.Controls.Add(this.pnl_Detalhes);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.pnl_Lista);
            this.Controls.Add(this.pnl_Titulo);
            this.Controls.Add(this.pnl_Botoes);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "frmProprietario";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.pnl_Detalhes.ResumeLayout(false);
            this.pnl_Detalhes.PerformLayout();
            this.pnl_Lista.ResumeLayout(false);
            this.pnl_Botoes.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnl_Detalhes;
        private System.Windows.Forms.Button btn_Alterar;
        private System.Windows.Forms.MaskedTextBox tbox_dtProprietario;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox tbox_telProprietario;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox tbox_celProprietario;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tbox_emaProprietario;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tbox_cepProprietario;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tbox_ufProprietario;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbox_baiProprietario;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbox_endProprietario;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbox_cpfProprietario;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbox_rgProprietario;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbox_nmProprietario;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnl_Lista;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel pnl_Titulo;
        private System.Windows.Forms.Panel pnl_Botoes;
        private System.Windows.Forms.Button btn_Novo;
        private System.Windows.Forms.Button btn_Confirmar;
        private System.Windows.Forms.Button btn_Cancelar;
        private System.Windows.Forms.ListBox lbox_objProprietario;
        private System.Windows.Forms.TextBox tbox_codProprietario;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btn_Excluir;
        private System.Windows.Forms.CheckBox cbox_Juridica;
    }
}