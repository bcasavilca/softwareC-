﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ImovCadastro
{
    public partial class frmImovel : Form
    {
        public FuncGeral FcGeral = new FuncGeral();
        public Imovel objImovel = new Imovel();




        public frmImovel()
        {
            InitializeComponent();
            FcGeral.HabilitaTela(this, false);
            PopulaLista();
            FcGeral.StatusBtn(this, 0);

        }

        private void btn_Novo_Click(object sender, EventArgs e)
        {
            //Habilitar a Tela
            FcGeral.HabilitaTela(this, true);
            //Limpar a Tela
            FcGeral.LimpaTela(this);
            //Arrumar Status dos Botões
            FcGeral.StatusBtn(this, 2);

            btn_Novo.Focus();
        }

        /**********************************************************************************
        * NOME:            PopulaLista
        * CLASSE:          Preenche o listbox com os dados de Imovel que estão no Banco
        * DT CRIAÇÃO:      28/03/2019
        * DT ALTERAÇÃO:    -
        * ESCRITA POR:     Monstro (mFacine)
        * OBSERVAÇÕES:     
        * ********************************************************************************/
        private void PopulaLista()
        {
            BDImovel objBDImovel = new ImovCadastro.BDImovel();
            List<Imovel> Lista = new List<Imovel>();
            Lista = objBDImovel.FindAllImovel();

            lbox_objImovel.Items.Clear();

            if (Lista != null)
            {
                for (int i = 0; i < Lista.Count; i++)
                {
                    lbox_objImovel.Items.Add(Convert.ToString(Lista[i].codImovel) + "-" + Lista[i].endImovel);
                }
            }

        }


        private void lbox_objImovel_DoubleClick(object sender, EventArgs e)
        {
            BDImovel objBDImovel = new BDImovel();
            string slinha = lbox_objImovel.Items[lbox_objImovel.SelectedIndex].ToString();

            int ipos = 0;

            for (int t = 0; t <= slinha.Length; t++)
            {
                if (slinha.Substring(t, 1) == "-")
                {
                    ipos = t;
                    break;
                }
            }

            objImovel.codImovel = Convert.ToInt16(slinha.Substring(0, ipos));

            objImovel = objBDImovel.FindByImovel(objImovel);
            PopulaTela(objImovel);
            FcGeral.HabilitaTela(this, false);
            FcGeral.StatusBtn(this, 1);
            tbox_codProprietario.Focus();
        }


        /**********************************************************************************
        * NOME:            PopulaTela
        * CLASSE:          Preenche o objeto Imovel no formulário
        * DT CRIAÇÃO:      28/03/2019
        * DT ALTERAÇÃO:    -
        * ESCRITA POR:     Monstro (mFacine)
        * OBSERVAÇÕES:     
        * ********************************************************************************/
        private void PopulaTela(Imovel objPoTeImovel)
        {
           
                tbox_codProprietario.Text = Convert.ToString(objPoTeImovel.codProprietario);

                tbox_cepImovel.Text = objPoTeImovel.cepImovel;
                tbox_endImovel.Text = objPoTeImovel.endImovel;
                tbox_dtcadImovel.Text = Convert.ToString(objPoTeImovel.dtcadImovel);
                tbox_baiImovel.Text = objPoTeImovel.baiImovel;
                tbox_ufImovel.Text = objPoTeImovel.ufImovel;
                tbox_codImovel.Text = Convert.ToString(objPoTeImovel.codImovel);

        }

        private void btn_Alterar_Click(object sender, EventArgs e)
        {
            FcGeral.HabilitaTela(this, true);
            FcGeral.StatusBtn(this, 2);
            tbox_codImovel.Focus();
        }

        private void btn_Excluir_Click(object sender, EventArgs e)
        {
            //Instancia a classe BDImovel
            BDImovel objBDImovel = new BDImovel();

            DialogResult varResp = MessageBox.Show("Confirma a Exclusão?", "EXCLUSÃO DE Imovel", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (varResp == DialogResult.Yes)
            {
                //Popula o objeto
                objImovel = PopulaObjeto();

                //Executa o Metodo Excluir da Classe BDImovel
                if (objBDImovel.Excluir(objImovel))
                {
                    MessageBox.Show("Imovel excluida com sucesso.", "EXCLUSÃO DE Imovel", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                FcGeral.LimpaTela(this);
                FcGeral.HabilitaTela(this, false);
                FcGeral.StatusBtn(this, 0);
            }
        }

        /**********************************************************************************
        * NOME:            PopulaObjeto
        * CLASSE:          Preenche o objeto Imovel com os dados do formulário
        * DT CRIAÇÃO:      28/03/2019
        * DT ALTERAÇÃO:    -
        * ESCRITA POR:     Monstro (mFacine)
        * OBSERVAÇÕES:     
        * ********************************************************************************/
        private Imovel PopulaObjeto()
        {
            Imovel objPoObImovel = new Imovel();

            if (tbox_codImovel.Text == "")
            {
                
                objPoObImovel.cepImovel     =   tbox_cepImovel.Text;
                objPoObImovel.endImovel     =   tbox_endImovel.Text;
                objPoObImovel.dtcadImovel   =   Convert.ToDateTime(tbox_dtcadImovel.Text);
                objPoObImovel.baiImovel     =   tbox_baiImovel.Text;
                objPoObImovel.ufImovel      =   tbox_ufImovel.Text;

                objPoObImovel.codImovel = -1;
            }
            else
            {
                objPoObImovel.cepImovel     =   tbox_cepImovel.Text;
                objPoObImovel.endImovel     =   tbox_endImovel.Text;
                objPoObImovel.dtcadImovel   =   Convert.ToDateTime(tbox_dtcadImovel.Text);
                objPoObImovel.baiImovel     =   tbox_baiImovel.Text;
                objPoObImovel.ufImovel      =   tbox_ufImovel.Text;

                objPoObImovel.codImovel = Convert.ToInt16(tbox_codImovel.Text);
            }

            return objPoObImovel;
        }

        private void btn_Confirmar_Click(object sender, EventArgs e)
        {
            if (FcGeral.CampoVazio(this))
            {
                MessageBox.Show("Campo vazio, favor verificar!!!.", "ENTRADA INVÁLIDA", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {

                //Instancia a classe BDProprietario
                BDImovel objBDImovel = new BDImovel();

                //Popula o objeto
                objImovel = PopulaObjeto();

                ////Executa o Metodo Alterar/Incluir da Classe BDProprietario



                if (objImovel.codProprietario != -1)
                {
                    objBDImovel.Alterar(objImovel);
                    MessageBox.Show("Proprietário alterada com sucesso.", "ALTERAÇÃO DE PROPRIETÁRIO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    tbox_codImovel.Text = Convert.ToString(objBDImovel.Incluir(objImovel));
                    MessageBox.Show("Proprietário incluida com sucesso.", "INCLUSÃO DE PROPRIETÁRIO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }




            FcGeral.StatusBtn(this, 1);
            FcGeral.HabilitaTela(this, false);
            PopulaLista();

        }

    private void btn_Cancelar_Click(object sender, EventArgs e)
        {
            PopulaTela(objImovel);
            FcGeral.HabilitaTela(this, false);
            FcGeral.StatusBtn(this, 1);
            PopulaLista();
        }

        private void btn_BuscaProprietario_Click(object sender, EventArgs e)
        {
            frmProprietario objfrmProprietario = new frmProprietario();
            objfrmProprietario.ShowDialog();
        }

        private void tbox_codProprietario_Leave(object sender, EventArgs e)
        {
            if (tbox_codProprietario.Text != "")
            {
                BDProprietario objBDProprietario = new BDProprietario();
                Proprietario objProprietario = new Proprietario();

                objProprietario.codProprietario = Convert.ToInt16(tbox_codProprietario.Text);

                objProprietario = objBDProprietario.FindByCategoria(objProprietario);
                if (objProprietario == null)
                {
                    MessageBox.Show("Código da Proprietario não existe.", "CONSULTA INVÁLIDA", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    tbox_codProprietario.Focus();
                }
                else
                {
                    lb_nmProprietario.Text =objProprietario.nmProprietario;
                }
            }
        }


    }
}
