﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ImovCadastro
{
    public partial class Principal : Form
    {
        public Principal()
        {
            InitializeComponent();

        }

        private void sAIRToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
        
        private void iMÓVELToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmImovel objfrmImovel = new frmImovel();
            objfrmImovel.ShowDialog();
        }

        private void pROPRIETÁRIOToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmProprietario objfrmProprietario = new frmProprietario();
            objfrmProprietario.ShowDialog();
        }
    }
}
