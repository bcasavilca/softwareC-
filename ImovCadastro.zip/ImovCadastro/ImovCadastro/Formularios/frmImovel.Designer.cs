﻿namespace ImovCadastro
{
    partial class frmImovel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmImovel));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.pnl_Botoes = new System.Windows.Forms.Panel();
            this.btn_Excluir = new System.Windows.Forms.Button();
            this.btn_Novo = new System.Windows.Forms.Button();
            this.btn_Confirmar = new System.Windows.Forms.Button();
            this.btn_Cancelar = new System.Windows.Forms.Button();
            this.btn_Alterar = new System.Windows.Forms.Button();
            this.pnl_Detalhes = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.tbox_codProprietario = new System.Windows.Forms.TextBox();
            this.lb_nmProprietario = new System.Windows.Forms.Label();
            this.btn_BuscaProprietario = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.tbox_dtcadImovel = new System.Windows.Forms.TextBox();
            this.tbox_cepImovel = new System.Windows.Forms.TextBox();
            this.tbox_ufImovel = new System.Windows.Forms.TextBox();
            this.tbox_baiImovel = new System.Windows.Forms.TextBox();
            this.tbox_endImovel = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbox_codImovel = new System.Windows.Forms.TextBox();
            this.lbox_objImovel = new System.Windows.Forms.ListBox();
            this.pnl_Lista = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.pnl_Botoes.SuspendLayout();
            this.pnl_Detalhes.SuspendLayout();
            this.pnl_Lista.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.label3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(657, 80);
            this.panel1.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(250, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(205, 55);
            this.label3.TabIndex = 3;
            this.label3.Text = "IMOVEL";
            // 
            // pnl_Botoes
            // 
            this.pnl_Botoes.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pnl_Botoes.Controls.Add(this.btn_Excluir);
            this.pnl_Botoes.Controls.Add(this.btn_Novo);
            this.pnl_Botoes.Controls.Add(this.btn_Confirmar);
            this.pnl_Botoes.Controls.Add(this.btn_Cancelar);
            this.pnl_Botoes.Controls.Add(this.btn_Alterar);
            this.pnl_Botoes.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnl_Botoes.Location = new System.Drawing.Point(0, 283);
            this.pnl_Botoes.Name = "pnl_Botoes";
            this.pnl_Botoes.Size = new System.Drawing.Size(657, 65);
            this.pnl_Botoes.TabIndex = 2;
            // 
            // btn_Excluir
            // 
            this.btn_Excluir.Location = new System.Drawing.Point(237, 14);
            this.btn_Excluir.Name = "btn_Excluir";
            this.btn_Excluir.Size = new System.Drawing.Size(100, 37);
            this.btn_Excluir.TabIndex = 72;
            this.btn_Excluir.Text = "EXCLUIR";
            this.btn_Excluir.UseVisualStyleBackColor = true;
            this.btn_Excluir.Click += new System.EventHandler(this.btn_Excluir_Click);
            // 
            // btn_Novo
            // 
            this.btn_Novo.Location = new System.Drawing.Point(25, 14);
            this.btn_Novo.Name = "btn_Novo";
            this.btn_Novo.Size = new System.Drawing.Size(100, 37);
            this.btn_Novo.TabIndex = 71;
            this.btn_Novo.Text = "NOVO";
            this.btn_Novo.UseVisualStyleBackColor = true;
            this.btn_Novo.Click += new System.EventHandler(this.btn_Novo_Click);
            // 
            // btn_Confirmar
            // 
            this.btn_Confirmar.Location = new System.Drawing.Point(538, 14);
            this.btn_Confirmar.Name = "btn_Confirmar";
            this.btn_Confirmar.Size = new System.Drawing.Size(100, 37);
            this.btn_Confirmar.TabIndex = 70;
            this.btn_Confirmar.Text = "CONFIRMAR";
            this.btn_Confirmar.UseVisualStyleBackColor = true;
            this.btn_Confirmar.Click += new System.EventHandler(this.btn_Confirmar_Click);
            // 
            // btn_Cancelar
            // 
            this.btn_Cancelar.Location = new System.Drawing.Point(432, 14);
            this.btn_Cancelar.Name = "btn_Cancelar";
            this.btn_Cancelar.Size = new System.Drawing.Size(100, 37);
            this.btn_Cancelar.TabIndex = 69;
            this.btn_Cancelar.Text = "CANCELAR";
            this.btn_Cancelar.UseVisualStyleBackColor = true;
            this.btn_Cancelar.Click += new System.EventHandler(this.btn_Cancelar_Click);
            // 
            // btn_Alterar
            // 
            this.btn_Alterar.Location = new System.Drawing.Point(131, 14);
            this.btn_Alterar.Name = "btn_Alterar";
            this.btn_Alterar.Size = new System.Drawing.Size(100, 37);
            this.btn_Alterar.TabIndex = 68;
            this.btn_Alterar.Text = "ALTERAR";
            this.btn_Alterar.UseVisualStyleBackColor = true;
            this.btn_Alterar.Click += new System.EventHandler(this.btn_Alterar_Click);
            // 
            // pnl_Detalhes
            // 
            this.pnl_Detalhes.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.pnl_Detalhes.Controls.Add(this.label8);
            this.pnl_Detalhes.Controls.Add(this.tbox_codProprietario);
            this.pnl_Detalhes.Controls.Add(this.lb_nmProprietario);
            this.pnl_Detalhes.Controls.Add(this.btn_BuscaProprietario);
            this.pnl_Detalhes.Controls.Add(this.label2);
            this.pnl_Detalhes.Controls.Add(this.tbox_dtcadImovel);
            this.pnl_Detalhes.Controls.Add(this.tbox_cepImovel);
            this.pnl_Detalhes.Controls.Add(this.tbox_ufImovel);
            this.pnl_Detalhes.Controls.Add(this.tbox_baiImovel);
            this.pnl_Detalhes.Controls.Add(this.tbox_endImovel);
            this.pnl_Detalhes.Controls.Add(this.label1);
            this.pnl_Detalhes.Controls.Add(this.label7);
            this.pnl_Detalhes.Controls.Add(this.label6);
            this.pnl_Detalhes.Controls.Add(this.label5);
            this.pnl_Detalhes.Controls.Add(this.label4);
            this.pnl_Detalhes.Controls.Add(this.tbox_codImovel);
            this.pnl_Detalhes.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnl_Detalhes.Location = new System.Drawing.Point(170, 80);
            this.pnl_Detalhes.Name = "pnl_Detalhes";
            this.pnl_Detalhes.Size = new System.Drawing.Size(487, 203);
            this.pnl_Detalhes.TabIndex = 4;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(12, 25);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(166, 20);
            this.label8.TabIndex = 27;
            this.label8.Text = "Código do Proprietário";
            // 
            // tbox_codProprietario
            // 
            this.tbox_codProprietario.Location = new System.Drawing.Point(184, 25);
            this.tbox_codProprietario.Name = "tbox_codProprietario";
            this.tbox_codProprietario.Size = new System.Drawing.Size(53, 20);
            this.tbox_codProprietario.TabIndex = 0;
            this.tbox_codProprietario.Leave += new System.EventHandler(this.tbox_codProprietario_Leave);
            // 
            // lb_nmProprietario
            // 
            this.lb_nmProprietario.BackColor = System.Drawing.Color.White;
            this.lb_nmProprietario.Location = new System.Drawing.Point(274, 25);
            this.lb_nmProprietario.Name = "lb_nmProprietario";
            this.lb_nmProprietario.Size = new System.Drawing.Size(167, 22);
            this.lb_nmProprietario.TabIndex = 25;
            this.lb_nmProprietario.Tag = "1";
            // 
            // btn_BuscaProprietario
            // 
            this.btn_BuscaProprietario.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_BuscaProprietario.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_BuscaProprietario.FlatAppearance.BorderSize = 0;
            this.btn_BuscaProprietario.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btn_BuscaProprietario.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btn_BuscaProprietario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_BuscaProprietario.Image = ((System.Drawing.Image)(resources.GetObject("btn_BuscaProprietario.Image")));
            this.btn_BuscaProprietario.Location = new System.Drawing.Point(243, 25);
            this.btn_BuscaProprietario.Name = "btn_BuscaProprietario";
            this.btn_BuscaProprietario.Size = new System.Drawing.Size(25, 23);
            this.btn_BuscaProprietario.TabIndex = 24;
            this.btn_BuscaProprietario.UseVisualStyleBackColor = true;
            this.btn_BuscaProprietario.Click += new System.EventHandler(this.btn_BuscaProprietario_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(43, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(135, 20);
            this.label2.TabIndex = 23;
            this.label2.Text = "Data do Cadastro";
            // 
            // tbox_dtcadImovel
            // 
            this.tbox_dtcadImovel.Location = new System.Drawing.Point(184, 55);
            this.tbox_dtcadImovel.Name = "tbox_dtcadImovel";
            this.tbox_dtcadImovel.Size = new System.Drawing.Size(79, 20);
            this.tbox_dtcadImovel.TabIndex = 1;
            // 
            // tbox_cepImovel
            // 
            this.tbox_cepImovel.Location = new System.Drawing.Point(184, 136);
            this.tbox_cepImovel.Name = "tbox_cepImovel";
            this.tbox_cepImovel.Size = new System.Drawing.Size(111, 20);
            this.tbox_cepImovel.TabIndex = 5;
            // 
            // tbox_ufImovel
            // 
            this.tbox_ufImovel.Location = new System.Drawing.Point(338, 109);
            this.tbox_ufImovel.Name = "tbox_ufImovel";
            this.tbox_ufImovel.Size = new System.Drawing.Size(34, 20);
            this.tbox_ufImovel.TabIndex = 4;
            // 
            // tbox_baiImovel
            // 
            this.tbox_baiImovel.Location = new System.Drawing.Point(184, 110);
            this.tbox_baiImovel.Name = "tbox_baiImovel";
            this.tbox_baiImovel.Size = new System.Drawing.Size(111, 20);
            this.tbox_baiImovel.TabIndex = 3;
            // 
            // tbox_endImovel
            // 
            this.tbox_endImovel.Location = new System.Drawing.Point(184, 84);
            this.tbox_endImovel.Name = "tbox_endImovel";
            this.tbox_endImovel.Size = new System.Drawing.Size(188, 20);
            this.tbox_endImovel.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(47, 162);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 20);
            this.label1.TabIndex = 17;
            this.label1.Text = "Código do Imóvel";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(137, 136);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 20);
            this.label7.TabIndex = 16;
            this.label7.Text = "CEP";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(301, 110);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(31, 20);
            this.label6.TabIndex = 15;
            this.label6.Text = "UF";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(128, 108);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 20);
            this.label5.TabIndex = 14;
            this.label5.Text = "Bairro";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(101, 82);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 20);
            this.label4.TabIndex = 13;
            this.label4.Text = "Endereço";
            // 
            // tbox_codImovel
            // 
            this.tbox_codImovel.Enabled = false;
            this.tbox_codImovel.Location = new System.Drawing.Point(184, 162);
            this.tbox_codImovel.Name = "tbox_codImovel";
            this.tbox_codImovel.Size = new System.Drawing.Size(53, 20);
            this.tbox_codImovel.TabIndex = 0;
            this.tbox_codImovel.Tag = "1";
            // 
            // lbox_objImovel
            // 
            this.lbox_objImovel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbox_objImovel.FormattingEnabled = true;
            this.lbox_objImovel.Location = new System.Drawing.Point(0, 0);
            this.lbox_objImovel.Name = "lbox_objImovel";
            this.lbox_objImovel.Size = new System.Drawing.Size(170, 203);
            this.lbox_objImovel.TabIndex = 5;
            this.lbox_objImovel.SelectedIndexChanged += new System.EventHandler(this.lbox_objImovel_DoubleClick);
            this.lbox_objImovel.DoubleClick += new System.EventHandler(this.lbox_objImovel_DoubleClick);
            // 
            // pnl_Lista
            // 
            this.pnl_Lista.Controls.Add(this.lbox_objImovel);
            this.pnl_Lista.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_Lista.Location = new System.Drawing.Point(0, 80);
            this.pnl_Lista.Name = "pnl_Lista";
            this.pnl_Lista.Size = new System.Drawing.Size(170, 203);
            this.pnl_Lista.TabIndex = 6;
            // 
            // frmImovel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(657, 348);
            this.Controls.Add(this.pnl_Lista);
            this.Controls.Add(this.pnl_Detalhes);
            this.Controls.Add(this.pnl_Botoes);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "frmImovel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "frmImovel";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pnl_Botoes.ResumeLayout(false);
            this.pnl_Detalhes.ResumeLayout(false);
            this.pnl_Detalhes.PerformLayout();
            this.pnl_Lista.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel pnl_Botoes;
        private System.Windows.Forms.Button btn_Excluir;
        private System.Windows.Forms.Button btn_Novo;
        private System.Windows.Forms.Button btn_Confirmar;
        private System.Windows.Forms.Button btn_Cancelar;
        private System.Windows.Forms.Button btn_Alterar;
        private System.Windows.Forms.Panel pnl_Detalhes;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbox_dtcadImovel;
        private System.Windows.Forms.TextBox tbox_cepImovel;
        private System.Windows.Forms.TextBox tbox_ufImovel;
        private System.Windows.Forms.TextBox tbox_baiImovel;
        private System.Windows.Forms.TextBox tbox_endImovel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbox_codImovel;
        private System.Windows.Forms.ListBox lbox_objImovel;
        private System.Windows.Forms.Panel pnl_Lista;
        private System.Windows.Forms.Label lb_nmProprietario;
        private System.Windows.Forms.Button btn_BuscaProprietario;
        private System.Windows.Forms.TextBox tbox_codProprietario;
        private System.Windows.Forms.Label label8;
    }
}