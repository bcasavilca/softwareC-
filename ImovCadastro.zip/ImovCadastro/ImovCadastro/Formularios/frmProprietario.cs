﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ImovCadastro
{
    public partial class frmProprietario : Form
    {
        public FuncGeral FcGeral = new FuncGeral();
        public Proprietario objProprietario = new Proprietario();




        public frmProprietario()
        {
            InitializeComponent();
            FcGeral.HabilitaTela(this, false);
            PopulaLista();
            FcGeral.StatusBtn(this, 0);

        }

        private void btn_Novo_Click(object sender, EventArgs e)
        {
            //Habilitar a Tela
            FcGeral.HabilitaTela(this, true);
            //Limpar a Tela
            FcGeral.LimpaTela(this);
            //Arrumar Status dos Botões
            FcGeral.StatusBtn(this, 2);

            tbox_nmProprietario.Focus();

        }

        /**********************************************************************************
        * NOME:            PopulaLista
        * CLASSE:          Preenche o listbox com os dados de Proprietarios que estão no Banco
        * DT CRIAÇÃO:      28/03/2019
        * DT ALTERAÇÃO:    -
        * ESCRITA POR:     Monstro (mFacine)
        * OBSERVAÇÕES:     
        * ********************************************************************************/
        private void PopulaLista()
        {
            BDProprietario objBDProprietario = new ImovCadastro.BDProprietario();
            List<Proprietario> Lista = new List<Proprietario>();
            Lista = objBDProprietario.FindAllProprietario();

            lbox_objProprietario.Items.Clear();

            if (Lista != null)
            {
                for (int i = 0; i < Lista.Count; i++)
                {
                    lbox_objProprietario.Items.Add(Convert.ToString(Lista[i].codProprietario) + "-" + Lista[i].nmProprietario);
                }
            }

        }

        private void lbox_objProprietarios_MouseDoubleClick(object sender, MouseEventArgs e)
        {

        }

        private void lbox_objProprietarios_DoubleClick(object sender, EventArgs e)
        {
            BDProprietario objBDProprietario = new BDProprietario();
            string slinha = lbox_objProprietario.Items[lbox_objProprietario.SelectedIndex].ToString();

            int ipos = 0;

            for (int t = 0; t <= slinha.Length; t++)
            {
                if (slinha.Substring(t, 1) == "-")
                {
                    ipos = t;
                    break;
                }
            }

            objProprietario.codProprietario = Convert.ToInt16(slinha.Substring(0, ipos));

            objProprietario = objBDProprietario.FindByCategoria(objProprietario);
            PopulaTela(objProprietario);
            FcGeral.HabilitaTela(this, false);
            FcGeral.StatusBtn(this, 1);
            //tbox_codCategoria.Focus();
        }


        /**********************************************************************************
        * NOME:            PopulaTela
        * CLASSE:          Preenche o objeto Proprietario no formulário
        * DT CRIAÇÃO:      28/03/2019
        * DT ALTERAÇÃO:    -
        * ESCRITA POR:     Monstro (mFacine)
        * OBSERVAÇÕES:     
        * ********************************************************************************/
        private void PopulaTela(Proprietario objPoTeProprietario)
        {
            if (objPoTeProprietario != null)
            {
                tbox_nmProprietario.Text = objPoTeProprietario.nmProprietario;
                tbox_rgProprietario.Text = objPoTeProprietario.rgProprietario;
                tbox_cpfProprietario.Text = objPoTeProprietario.cpfProprietario;
                tbox_endProprietario.Text = objPoTeProprietario.endProprietario;
                tbox_baiProprietario.Text = objPoTeProprietario.baiProprietario;
                tbox_ufProprietario.Text = objPoTeProprietario.ufProprietario;
                tbox_cepProprietario.Text = objPoTeProprietario.cepProprietario;
                tbox_emaProprietario.Text = objPoTeProprietario.emaProprietario;
                tbox_celProprietario.Text = objPoTeProprietario.celProprietario;
                tbox_telProprietario.Text = objPoTeProprietario.telProprietario;
                cbox_Juridica.Checked = objPoTeProprietario.tpProprietario;
                tbox_codProprietario.Text = Convert.ToString(objPoTeProprietario.codProprietario);
                tbox_dtProprietario.Text = Convert.ToString(objPoTeProprietario.dtnascProprietario);
            }

        }

        private void btn_Alterar_Click(object sender, EventArgs e)
        {
            FcGeral.HabilitaTela(this, true);
            FcGeral.StatusBtn(this, 2);
            tbox_codProprietario.Focus();
        }

        private void btn_Excluir_Click(object sender, EventArgs e)
        {
            //Instancia a classe BDProprietario
            BDProprietario objBDProprietario = new BDProprietario();

            DialogResult varResp = MessageBox.Show("Confirma a Exclusão?", "EXCLUSÃO DE PROPRIETÁRIO", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (varResp == DialogResult.Yes)
            {
                //Popula o objeto
                objProprietario = PopulaObjeto();

                //Executa o Metodo Excluir da Classe BDProprietario
                if (objBDProprietario.Excluir(objProprietario))
                {
                    MessageBox.Show("Proprietario excluida com sucesso.", "EXCLUSÃO DE PROPRIETÁRIO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                FcGeral.LimpaTela(this);
                FcGeral.HabilitaTela(this, false);
                FcGeral.StatusBtn(this, 0);
            }
        }

        /**********************************************************************************
        * NOME:            PopulaObjeto
        * CLASSE:          Preenche o objeto Proprietario com os dados do formulário
        * DT CRIAÇÃO:      28/03/2019
        * DT ALTERAÇÃO:    -
        * ESCRITA POR:     Monstro (mFacine)
        * OBSERVAÇÕES:     
        * ********************************************************************************/
        private Proprietario PopulaObjeto()
        {
            Proprietario objPoObProprietario = new Proprietario();

            if (tbox_codProprietario.Text == "")
            {

                objPoObProprietario.nmProprietario = tbox_nmProprietario.Text;
                objPoObProprietario.rgProprietario = tbox_rgProprietario.Text;
                objPoObProprietario.cpfProprietario = tbox_cpfProprietario.Text;
                objPoObProprietario.endProprietario = tbox_endProprietario.Text;
                objPoObProprietario.baiProprietario = tbox_baiProprietario.Text;
                objPoObProprietario.ufProprietario = tbox_ufProprietario.Text;
                objPoObProprietario.cepProprietario = tbox_cepProprietario.Text;
                objPoObProprietario.emaProprietario = tbox_emaProprietario.Text;
                objPoObProprietario.celProprietario = tbox_celProprietario.Text;
                objPoObProprietario.telProprietario = tbox_telProprietario.Text;
                objPoObProprietario.dtnascProprietario = Convert.ToDateTime(tbox_dtProprietario.Text);
                objPoObProprietario.tpProprietario = cbox_Juridica.Checked;

                objPoObProprietario.codProprietario = -1;
            }
            else
            {
                objPoObProprietario.nmProprietario = tbox_nmProprietario.Text;
                objPoObProprietario.rgProprietario = tbox_rgProprietario.Text;
                objPoObProprietario.cpfProprietario = tbox_cpfProprietario.Text;
                objPoObProprietario.endProprietario = tbox_endProprietario.Text;
                objPoObProprietario.baiProprietario = tbox_baiProprietario.Text;
                objPoObProprietario.ufProprietario = tbox_ufProprietario.Text;
                objPoObProprietario.cepProprietario = tbox_cepProprietario.Text;
                objPoObProprietario.emaProprietario = tbox_emaProprietario.Text;
                objPoObProprietario.celProprietario = tbox_celProprietario.Text;
                objPoObProprietario.telProprietario = tbox_telProprietario.Text;
                objPoObProprietario.tpProprietario = cbox_Juridica.Checked;
                objPoObProprietario.dtnascProprietario = Convert.ToDateTime(tbox_dtProprietario.Text);
                objPoObProprietario.codProprietario = Convert.ToInt16(tbox_codProprietario.Text);
            }

            return objPoObProprietario;
        }

        private void btn_Confirmar_Click(object sender, EventArgs e)
        {
            if (FcGeral.CampoVazio(this))
            {
                MessageBox.Show("Campo vazio, favor verificar!!!.", "ENTRADA INVÁLIDA", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {

                //Instancia a classe BDProprietario
                BDProprietario objBDProprietario = new BDProprietario();

                //Popula o objeto
                objProprietario = PopulaObjeto();

                ////Executa o Metodo Alterar/Incluir da Classe BDProprietario



                if (objProprietario.codProprietario != -1)
                {
                    objBDProprietario.Alterar(objProprietario);
                    MessageBox.Show("Proprietário alterada com sucesso.", "ALTERAÇÃO DE PROPRIETÁRIO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    tbox_codProprietario.Text = Convert.ToString(objBDProprietario.Incluir(objProprietario));
                    MessageBox.Show("Proprietário incluida com sucesso.", "INCLUSÃO DE PROPRIETÁRIO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }




            FcGeral.StatusBtn(this, 1);
            FcGeral.HabilitaTela(this, false);
            PopulaLista();

        }


 

        private void btn_Cancelar_Click(object sender, EventArgs e)
        {
            PopulaTela(objProprietario);
            FcGeral.HabilitaTela(this, false);
            if (objProprietario.codProprietario != -1)
            {
                FcGeral.StatusBtn(this, 1);
            }
            else
            {
                FcGeral.StatusBtn(this, 0);
            }

            PopulaLista();
        }

    }
}


