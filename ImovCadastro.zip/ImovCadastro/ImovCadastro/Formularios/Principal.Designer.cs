﻿namespace ImovCadastro
{
    partial class Principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.btn_Novo = new System.Windows.Forms.ToolStripMenuItem();
            this.pROPRIETÁRIOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iMÓVELToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sAIRToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Corbel", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(60, 400);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1383, 78);
            this.label1.TabIndex = 0;
            this.label1.Text = "ImovCadastro";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btn_Novo,
            this.sAIRToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(938, 24);
            this.menuStrip1.TabIndex = 26;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // btn_Novo
            // 
            this.btn_Novo.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pROPRIETÁRIOToolStripMenuItem,
            this.iMÓVELToolStripMenuItem});
            this.btn_Novo.Name = "btn_Novo";
            this.btn_Novo.Size = new System.Drawing.Size(80, 20);
            this.btn_Novo.Text = "CADASTRO";
            // 
            // pROPRIETÁRIOToolStripMenuItem
            // 
            this.pROPRIETÁRIOToolStripMenuItem.Name = "pROPRIETÁRIOToolStripMenuItem";
            this.pROPRIETÁRIOToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.pROPRIETÁRIOToolStripMenuItem.Text = "PROPRIETÁRIO";
            this.pROPRIETÁRIOToolStripMenuItem.Click += new System.EventHandler(this.pROPRIETÁRIOToolStripMenuItem_Click);
            // 
            // iMÓVELToolStripMenuItem
            // 
            this.iMÓVELToolStripMenuItem.Name = "iMÓVELToolStripMenuItem";
            this.iMÓVELToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.iMÓVELToolStripMenuItem.Text = "IMÓVEL";
            this.iMÓVELToolStripMenuItem.Click += new System.EventHandler(this.iMÓVELToolStripMenuItem_Click);
            // 
            // sAIRToolStripMenuItem
            // 
            this.sAIRToolStripMenuItem.Name = "sAIRToolStripMenuItem";
            this.sAIRToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.sAIRToolStripMenuItem.Text = "SAIR";
            this.sAIRToolStripMenuItem.Click += new System.EventHandler(this.sAIRToolStripMenuItem_Click);
            // 
            // Principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(938, 542);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "Principal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem btn_Novo;
        private System.Windows.Forms.ToolStripMenuItem sAIRToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pROPRIETÁRIOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iMÓVELToolStripMenuItem;
    }
}