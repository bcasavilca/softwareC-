﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ImovCadastro
{
    public partial class frmProprietarioNovo : Form
    {
        public frmProprietarioNovo()
        {
            InitializeComponent();
        }

        private void frmNovo_Load(object sender, EventArgs e)
        {
      
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmImovelNovo objfrmImovelNovo = new frmImovelNovo();
            objfrmImovelNovo.ShowDialog();
        }
    }
}
