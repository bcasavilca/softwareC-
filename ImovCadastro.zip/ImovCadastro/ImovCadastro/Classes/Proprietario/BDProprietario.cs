﻿/**********************************************************************************
 * NOME:            BDProprietario
 * CLASSE:          Representação da classe Imovel que conecta com o 
 *                  banco de dados
 * DT CRIAÇÃO:      08/04/2019    
 * DT ALTERAÇÃO:    29/04/2019
 * ESCRITA POR:     Projeto Integrador (Bruno e Adão)
 * ********************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.IO;
using System.Dynamic;
using System.Windows.Forms;



namespace ImovCadastro
{
    class BDProprietario
    {
        /***********************************************************************
        * NOME          :  Incluir          
        * METODO        :  Responsável por incluir o Objeto na Base de Dados.
        *                  Inclui um registro na tabela tb_Categoria.         
        * DT CRIAÇÃO:      08/04/2019    
        * DT ALTERAÇÃO:    29/04/2019
        * ESCRITA POR:     Projeto Integrador (Bruno e Adão)
        * OBSERVAÇÕES   :  Utiliza a Classe Connection para acessar o BD.   
        **********************************************************************/
        public int Incluir(Proprietario aobjProprietario)
        {
            //(08/04/2019-Bruno e Adão) Cria objeto para a conexão com o banco de dados
            SqlConnection objCon = new SqlConnection(Connection.ConnectionPath());
            
            string varSql = "INSERT INTO tb_Proprietario" +
                        "(" +
                        "snmProprietario, " +
                        "srgProprietario, " +
                        "scpfProprietario, " +
                        "sendProprietario, " +
                        "sbaiProprietario, " +
                        "sufProprietario, " +
                        "scepProprietario, " +
                        "semaProprietario, " +
                        "scelProprietario, " +
                        "stelProprietario, " +
                        "dtnascProprietario, " +
                        "btpProprietario " +
                        ")" +
                        " VALUES" +
                        "(" +
                        "@snmProprietario, " +
                        "@srgProprietario, " +
                        "@scpfProprietario, " +
                        "@sendProprietario, " +
                        "@sbaiProprietario, " +
                        "@sufProprietario, " +
                        "@scepProprietario, " +
                        "@semaProprietario, " +
                        "@scelProprietario, " +
                        "@stelProprietario, " +
                        "@dtnascProprietario, " +
                        "@btpProprietario " +
                        "); " +
                        "SELECT ident_current('tb_Proprietario') as 'id'";

            SqlCommand objCmd = new SqlCommand(varSql, objCon);
            objCmd.Parameters.AddWithValue("@snmProprietario", aobjProprietario.nmProprietario);
            objCmd.Parameters.AddWithValue("@srgProprietario", aobjProprietario.rgProprietario);
            objCmd.Parameters.AddWithValue("@scpfProprietario", aobjProprietario.cpfProprietario);
            objCmd.Parameters.AddWithValue("@sendProprietario", aobjProprietario.endProprietario);
            objCmd.Parameters.AddWithValue("@sbaiProprietario", aobjProprietario.baiProprietario);
            objCmd.Parameters.AddWithValue("@sufProprietario", aobjProprietario.ufProprietario);
            objCmd.Parameters.AddWithValue("@scepProprietario", aobjProprietario.cepProprietario);
            objCmd.Parameters.AddWithValue("@semaProprietario", aobjProprietario.emaProprietario);
            objCmd.Parameters.AddWithValue("@scelProprietario", aobjProprietario.celProprietario);
            objCmd.Parameters.AddWithValue("@stelProprietario", aobjProprietario.telProprietario);
            objCmd.Parameters.AddWithValue("@dtnascProprietario", aobjProprietario.dtnascProprietario);
            objCmd.Parameters.AddWithValue("@btpProprietario", aobjProprietario.tpProprietario);
                   

            try
            {

                objCon.Open();
                int _id = Convert.ToInt16(objCmd.ExecuteScalar());
                objCon.Close();

                return _id;
            }
            catch (Exception erro)
            {
                MessageBox.Show(erro.Message, "ERRO FATAL", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
        }

        /***********************************************************************
         * NOME          :  Alterar          
         * METODO        :  Responsável por Editar o Objeto na Base de Dados.
         *                  Altera um registro na tabela tb_Categoria.          
         * DT CRIAÇÃO:      08/04/2019    
         * DT ALTERAÇÃO:    29/04/2019
         * ESCRITA POR:     Projeto Integrador (Bruno e Adão)   
         **********************************************************************/
        public bool Alterar(Proprietario aobjProprietario)
        {
            if (aobjProprietario.codProprietario != -1)
            {
                //(08/04/2019-Bruno e Adão) Cria objeto para a conexão com o banco de dados
                SqlConnection objCon = new SqlConnection(Connection.ConnectionPath());

                string varSql = " UPDATE tb_Proprietario SET " +
                        "snmProprietario  = @snmProprietario," +
                        "srgProprietario  = @srgProprietario," +
                        "scpfProprietario = @scpfProprietario," +
                        "sendProprietario = @sendProprietario," +
                        "sbaiProprietario = @sbaiProprietario," +
                        "sufProprietario  = @sufProprietario," +
                        "scepProprietario = @scepProprietario," +
                        "semaProprietario = @semaProprietario," +
                        "scelProprietario = @scelProprietario," +
                        "stelProprietario = @stelProprietario," +
                        "dtnascProprietario  = @dtnascProprietario," +
                        "btpProprietario  = @btpProprietario " +
                        " WHERE icodProprietario = @icodProprietario ";

                SqlCommand objCmd = new SqlCommand(varSql, objCon);
                objCmd.Parameters.AddWithValue("@icodProprietario", aobjProprietario.codProprietario);
                objCmd.Parameters.AddWithValue("@snmProprietario", aobjProprietario.nmProprietario);
                objCmd.Parameters.AddWithValue("@srgProprietario", aobjProprietario.rgProprietario);
                objCmd.Parameters.AddWithValue("@scpfProprietario", aobjProprietario.cpfProprietario);
                objCmd.Parameters.AddWithValue("@sendProprietario", aobjProprietario.endProprietario);
                objCmd.Parameters.AddWithValue("@sbaiProprietario", aobjProprietario.baiProprietario);
                objCmd.Parameters.AddWithValue("@sufProprietario", aobjProprietario.ufProprietario);
                objCmd.Parameters.AddWithValue("@scepProprietario", aobjProprietario.cepProprietario);
                objCmd.Parameters.AddWithValue("@semaProprietario", aobjProprietario.emaProprietario);
                objCmd.Parameters.AddWithValue("@scelProprietario", aobjProprietario.celProprietario);
                objCmd.Parameters.AddWithValue("@stelProprietario", aobjProprietario.telProprietario);
                objCmd.Parameters.AddWithValue("@dtnascProprietario", aobjProprietario.dtnascProprietario);
                objCmd.Parameters.AddWithValue("@btpProprietario", aobjProprietario.tpProprietario);



                try
                {

                    objCon.Open();
                    objCmd.ExecuteNonQuery();
                    objCon.Close();

                    return true;
                }
                catch (Exception erro)
                {
                    MessageBox.Show(erro.Message, "ERRO FATAL", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

            }
            else
            {
                return false;
            }
        }

        /***********************************************************************
        * NOME          :  Excluir          
        * METODO        :  Responsável por excluir o Objeto na Base de Dados.
        *                  Deleta um registro na tabela tb_Categoria.         
        * DT CRIAÇÃO:      08/04/2019    
        * DT ALTERAÇÃO:    29/04/2019
        * ESCRITA POR:     Projeto Integrador (Bruno e Adão) 
        * OBSERVAÇÕES   :  Utiliza a Classe Connection para acessar o BD.   
        **********************************************************************/
        public bool Excluir(Proprietario aobjProprietario)
        {
            SqlConnection objCon = new SqlConnection(Connection.ConnectionPath());
                
            //(08/04/2019-Bruno e Adão) Cria a variável que conterá o comando SQL
            string varSql = "DELETE FROM tb_Proprietario WHERE icodProprietario = @icodProprietario";

            //(08/04/2019-Bruno e Adão) Cria o objeto que executa o comando
            SqlCommand objCmd = new SqlCommand(varSql, objCon);
            objCmd.Parameters.AddWithValue("@icodProprietario", aobjProprietario.codProprietario);

            try
            {
                objCon.Open();
                objCmd.ExecuteNonQuery();
                objCon.Close();

                return true;
            }
            catch (Exception erro)
            {
                MessageBox.Show(erro.Message, "ERRO FATAL", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        /***********************************************************************
        * NOME          :  FindByCategoria       
        * METODO        :  Responsável por encontrar o Objeto na Base de Dados.
        *                  Busca um registro na tabela tb_Categoria.         
        * DT CRIAÇÃO:      08/04/2019    
        * DT ALTERAÇÃO:    29/04/2019
        * ESCRITA POR:     Projeto Integrador (Bruno e Adão)
        * OBSERVAÇÕES   :  Utiliza a Classe Connection para acessar o BD.   
        **********************************************************************/
        public Proprietario FindByCategoria(Proprietario aobjProprietario)
        {
            //(08/04/2019-Bruno e Adão) Cria objeto para a conexão com o banco de dados
            SqlConnection objCon = new SqlConnection(Connection.ConnectionPath());

            //(08/04/2019-Bruno e Adão) Cria a variável que conterá o comando SQL
            string varSql = "SELECT * FROM tb_Proprietario WHERE icodProprietario = @icodProprietario";

            //(08/04/2019-Bruno e Adão) Cria o objeto que executa o comando
            SqlCommand objCmd = new SqlCommand(varSql, objCon);
            objCmd.Parameters.AddWithValue("@icodProprietario", aobjProprietario.codProprietario);

            //(08/04/2019-Bruno e Adão) Abre a conexão com o banco de dados
            objCon.Open();

            //(08/04/2019-Bruno e Adão) Executa o comando para excluir o registro
            SqlDataReader objDtr = objCmd.ExecuteReader();

            //(08/04/2019-Bruno e Adão) Pergunta se existe linha no Reader
            if (objDtr.HasRows)
            {
                //(08/04/2019-Bruno e Adão) Lê os dados que estão no objDtr
                objDtr.Read();

                //(08/04/2019-Bruno e Adão) Coloca os dados do Reader no Objeto
              
                aobjProprietario.codProprietario = Convert.ToInt16(objDtr["icodProprietario"]);
                aobjProprietario.nmProprietario = objDtr["snmProprietario"].ToString();
                aobjProprietario.rgProprietario = objDtr["srgProprietario"].ToString();
                aobjProprietario.cpfProprietario = objDtr["scpfProprietario"].ToString();
                aobjProprietario.endProprietario = objDtr["sendProprietario"].ToString();
                aobjProprietario.baiProprietario = objDtr["sbaiProprietario"].ToString();
                aobjProprietario.ufProprietario = objDtr["sufProprietario"].ToString();
                aobjProprietario.cepProprietario = objDtr["scepProprietario"].ToString();
                aobjProprietario.emaProprietario = objDtr["semaProprietario"].ToString();
                aobjProprietario.celProprietario = objDtr["scelProprietario"].ToString();
                aobjProprietario.telProprietario = objDtr["stelProprietario"].ToString();
                aobjProprietario.dtnascProprietario = Convert.ToDateTime(objDtr["dtnascProprietario"]);
                aobjProprietario.tpProprietario = Convert.ToBoolean(objDtr["btpProprietario"]);
                


                //(08/04/2019-Bruno e Adão) Fecha a conexão com o banco de dados
                objCon.Close();

                //(08/04/2019-Bruno e Adão) Fecha o objeto Reader
                objDtr.Close();

                return aobjProprietario;
            }
            else
            {
                //(08/04/2019-Bruno e Adão) Fecha a conexão com o banco de dados
                objCon.Close();

                //(08/04/2019-Bruno e Adão) Fecha o objeto Reader
                objDtr.Close();

                return null;
            }
        }

        /***********************************************************************
        * NOME          :  FindAllCategoria       
        * METODO        :  Responsável por encontrar todos os Objetos na Base 
        *                  de Dados. Busca todos os registros na tabela tb_Categoria.         
        * DT CRIAÇÃO:      08/04/2019    
        * DT ALTERAÇÃO:    29/04/2019
        * ESCRITA POR:     Projeto Integrador (Bruno e Adão)  
        * OBSERVAÇÕES   :  Utiliza a Classe Connection para acessar o BD.   
        **********************************************************************/
        public List<Proprietario> FindAllProprietario()
        {
            //(08/04/2019-Bruno e Adão) Cria objeto para a conexão com o banco de dados
            SqlConnection objCon = new SqlConnection(Connection.ConnectionPath());

            //(08/04/2019-Bruno e Adão) Cria a variável que conterá o comando SQL
            string varSql = "SELECT * FROM tb_Proprietario";

            //(08/04/2019-Bruno e Adão) Cria o objeto que executa o comando
            SqlCommand objCmd = new SqlCommand(varSql, objCon);

            //(08/04/2019-Bruno e Adão) Abre a conexão com o banco de dados
            objCon.Open();

            //(08/04/2019-Bruno e Adão) Executa o comando para excluir o registro
            SqlDataReader objDtr = objCmd.ExecuteReader();

            List<Proprietario> lista = new List<Proprietario>();

            if (objDtr.HasRows)
            {
                //(08/04/2019-Bruno e Adão) Enquanto tiver linha faça
                while (objDtr.Read())
                {
                    //(08/04/2019-Bruno e Adão) Instância do objto Receita
                    Proprietario aobjProprietario = new Proprietario();

                    //(08/04/2019-Bruno e Adão) Coloca os dados do Reader no Objeto
                    
                    aobjProprietario.codProprietario = Convert.ToInt16(objDtr["icodProprietario"]);
                    aobjProprietario.nmProprietario = objDtr["snmProprietario"].ToString();
                    aobjProprietario.rgProprietario = objDtr["srgProprietario"].ToString();
                    aobjProprietario.cpfProprietario = objDtr["scpfProprietario"].ToString();
                    aobjProprietario.endProprietario = objDtr["sendProprietario"].ToString();
                    aobjProprietario.baiProprietario = objDtr["sbaiProprietario"].ToString();
                    aobjProprietario.ufProprietario = objDtr["sufProprietario"].ToString();
                    aobjProprietario.cepProprietario = objDtr["scepProprietario"].ToString();
                    aobjProprietario.emaProprietario = objDtr["semaProprietario"].ToString();
                    aobjProprietario.celProprietario = objDtr["scelProprietario"].ToString();
                    aobjProprietario.telProprietario = objDtr["stelProprietario"].ToString();
                    aobjProprietario.dtnascProprietario = Convert.ToDateTime(objDtr["dtnascProprietario"]);
                    aobjProprietario.tpProprietario = Convert.ToBoolean(objDtr["btpProprietario"]);



                    lista.Add(aobjProprietario);
                }
                //(08/04/2019-Bruno e Adão) Fecha a conexão com o banco de dados
                objCon.Close();

                //(08/04/2019-Bruno e Adão) Fecha o objeto Reader
                objDtr.Close();

                return lista;
            }
            else
            {
                //(08/04/2019-Bruno e Adão) Fecha a conexão com o banco de dados
                objCon.Close();

                //(08/04/2019-Bruno e Adão) Fecha o objeto Reader
                objDtr.Close();

                return null;
            }

        }

    }
}
