﻿/**********************************************************************************
 * NOME:            Proprietario
 * CLASSE:          Representação do objeto Proprietario
 * DT CRIAÇÃO:      08/04/2019    
 * DT ALTERAÇÃO:    29/04/2019
 * ESCRITA POR:     Projeto Integrador (Bruno e Adão)   
 * OBSERVAÇÕES:     Atributos privados com métodos Get e Set públicos
 * ********************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImovCadastro
{
    public class Proprietario
    {
        //Destructor da Classe
        ~Proprietario()
        {
        }

        //Atributos/Propriedades Privadas Encapsuladas
        private int vcodProprietario = -1;
        private string vendProprietario = "";
        private string vbaiProprietario = "";
        private string vufProprietario = "";
        private string vnmProprietario = "";
        private string vrgProprietario = "";
        private string vcpfProprietario = "";
        private string vemaProprietario = "";
        private string vcelProprietario = "";
        private string vtelProprietario = "";
        private bool vtpProprietario = false;
        private string vcepProprietario = "";
        private DateTime vdtnascProprietario = DateTime.MinValue;

        //Metodos/Ações Publicas

        /***********************************************************************
         * NOME:            codProprietario         
         * METODO:          Representação do atributo Código com os métodos 
         *                  Get e Set          
         * DT CRIAÇÃO:      08/04/2019    
         * DT ALTERAÇÃO:    29/04/2019
         * ESCRITA POR:     Projeto Integrador (Bruno e Adão)  
         **********************************************************************/
        public int codProprietario
        {
            get { return vcodProprietario; }
            set { vcodProprietario = value; }
        }

        /***********************************************************************
        * NOME:            endProprietario
        * METODO:          Representação do atributo endereço do Proprietario com os
        *                  métodos Get e Set          
        * DT CRIAÇÃO:      08/04/2019    
        * DT ALTERAÇÃO:    29/04/2019
        * ESCRITA POR:     Projeto Integrador (Bruno e Adão)    
        **********************************************************************/
        public string endProprietario
        {
            get { return vendProprietario; }
            set { vendProprietario = value; }
        }

        /***********************************************************************
         * NOME:            baiProprietario
         * METODO:          Representação do atributo bairro do Proprietario com os
         *                  métodos Get e Set          
         * DT CRIAÇÃO:      08/04/2019    
         * DT ALTERAÇÃO:    29/04/2019
         * ESCRITA POR:     Projeto Integrador (Bruno e Adão)   
         **********************************************************************/
        public string baiProprietario
        {
            get { return vbaiProprietario; }
            set { vbaiProprietario = value; }
        }

        /***********************************************************************
       * NOME:            ufProprietario
       * METODO:          Representação do atributo estado do Proprietario com os
       *                  métodos Get e Set          
       * DT CRIAÇÃO:      08/04/2019    
       * DT ALTERAÇÃO:    29/04/2019
       * ESCRITA POR:     Projeto Integrador (Bruno e Adão)   
       **********************************************************************/
        public string ufProprietario
        {
            get { return vufProprietario; }
            set { vufProprietario = value; }
        }

        /***********************************************************************
        * NOME:            nmProprietario
        * METODO:          Representação do atributo nome do Proprietario com os
        *                  métodos Get e Set          
        * DT CRIAÇÃO:      08/04/2019    
        * DT ALTERAÇÃO:    29/04/2019
        * ESCRITA POR:     Projeto Integrador (Bruno e Adão)    
        **********************************************************************/
        public string nmProprietario
        {
            get { return vnmProprietario; }
            set { vnmProprietario = value; }
        }

        /***********************************************************************
        * NOME:            rgProprietario
        * METODO:          Representação do atributo rg do Proprietario com os
        *                  métodos Get e Set          
        * DT CRIAÇÃO:      08/04/2019    
        * DT ALTERAÇÃO:    29/04/2019
        * ESCRITA POR:     Projeto Integrador (Bruno e Adão)   
        **********************************************************************/
        public string rgProprietario
        {
            get { return vrgProprietario; }
            set { vrgProprietario = value; }
        }

        /***********************************************************************
        * NOME:            cpfProprietario
        * METODO:          Representação do atributo cpf do Proprietario com os
        *                  métodos Get e Set          
        * DT CRIAÇÃO:      08/04/2019    
        * DT ALTERAÇÃO:    29/04/2019
        * ESCRITA POR:     Projeto Integrador (Bruno e Adão)    
        **********************************************************************/
        public string cpfProprietario
        {
            get { return vcpfProprietario; }
            set { vcpfProprietario = value; }
        }
        /***********************************************************************
        * NOME:            emaProprietario
        * METODO:          Representação do atributo email do Proprietario com os
        *                  métodos Get e Set          
        * DT CRIAÇÃO:      08/04/2019    
        * DT ALTERAÇÃO:    29/04/2019
        * ESCRITA POR:     Projeto Integrador (Bruno e Adão)   
        **********************************************************************/
        public string emaProprietario
        {
            get { return vemaProprietario; }
            set { vemaProprietario = value; }
        }
        /***********************************************************************
        * NOME:            celProprietario
        * METODO:          Representação do atributo cpf do Proprietario com os
        *                  métodos Get e Set          
        * DT CRIAÇÃO:      08/04/2019    
        * DT ALTERAÇÃO:    29/04/2019
        * ESCRITA POR:     Projeto Integrador (Bruno e Adão)   
        **********************************************************************/
        public string celProprietario
        {
            get { return vcelProprietario; }
            set { vcelProprietario = value; }
        }

        /***********************************************************************
        * NOME:            telProprietario
        * METODO:          Representação do atributo tel do Proprietario com os
        *                  métodos Get e Set          
        * DT CRIAÇÃO:      08/04/2019    
        * DT ALTERAÇÃO:    29/04/2019
        * ESCRITA POR:     Projeto Integrador (Bruno e Adão)    
        **********************************************************************/
        public string telProprietario
        {
            get { return vtelProprietario; }
            set { vtelProprietario = value; }
        }
        /***********************************************************************
        * NOME:            nascProprietario
        * METODO:          Representação do atributo data do nascimento do Proprietario com os
        *                  métodos Get e Set          
        * DT CRIAÇÃO:      08/04/2019    
        * DT ALTERAÇÃO:    29/04/2019
        * ESCRITA POR:     Projeto Integrador (Bruno e Adão)    
        **********************************************************************/
        public DateTime dtnascProprietario
        {
            get { return vdtnascProprietario; }
            set { vdtnascProprietario = value; }
        }
        /***********************************************************************
        * NOME:            tpProprietario
        * METODO:          Representação do atributo tipo do Proprietario com os
        *                  métodos Get e Set          
        * DT CRIAÇÃO:      08/04/2019    
        * DT ALTERAÇÃO:    29/04/2019
        * ESCRITA POR:     Projeto Integrador (Bruno e Adão)    
        **********************************************************************/
        public bool tpProprietario
        {
            get { return vtpProprietario; }
            set { vtpProprietario = value; }
        }
        /***********************************************************************
        * NOME:            codProprietario         
        * METODO:          Representação do atributo Código com os métodos 
        *                  Get e Set          
        * DT CRIAÇÃO:      08/04/2019    
        * DT ALTERAÇÃO:    29/04/2019
        * ESCRITA POR:     Projeto Integrador (Bruno e Adão)   
        **********************************************************************/
        public string cepProprietario
        {
            get { return vcepProprietario; }
            set { vcepProprietario = value; }
        }
    }
}