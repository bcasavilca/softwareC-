﻿/**********************************************************************************
 * NOME:            Connection
 * CLASSE:          Representação da classe de conexão
 * DT CRIAÇÃO:      08/04/2019    
 * DT ALTERAÇÃO:    29/04/2019
 * ESCRITA POR:     Projeto Integrador (Bruno e Adão)
 * OBSERVAÇÕES:     Classe que faz a conexão com o banco de dados
 * ********************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImovCadastro
{
    class Connection
    {
        //Metodo da classe que retorna o caminho da conexão
        public static string ConnectionPath()
        {
            return @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDBFilename=C:\Users\marcos.bjcasavilca\Documents\Visual Studio 2015\Projects\ImovCadastro\ImovCadastro\BDImovCadastro.mdf;Integrated Security=True; Connect Timeout = 30";
        }
    }
}
