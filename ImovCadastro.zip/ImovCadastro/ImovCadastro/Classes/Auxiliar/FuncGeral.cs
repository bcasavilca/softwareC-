﻿/**********************************************************************************
 * NOME:            FuncGeral
 * CLASSE:          Representação do objeto de Funções Gerais
 * DT CRIAÇÃO:      08/04/2019    
 * DT ALTERAÇÃO:    29/04/2019
 * ESCRITA POR:     Projeto Integrador (Bruno e Adão)
 * OBSERVAÇÕES:     Metodos utilizados por formulários e Classes
 * ********************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace ImovCadastro
{
    public class FuncGeral
    {
        /***********************************************************************
        * NOME:            LimpaTela       
        * METODO:          Limpa cada Componente editável que está no painel 
        *                  Detalhes
        * PARAMETRO:       Nome do Formulário                 
        * DT CRIAÇÃO:      08/04/2019    
        * DT ALTERAÇÃO:    29/04/2019
        * ESCRITA POR:     Projeto Integrador (Bruno e Adão)
        **********************************************************************/
        public void LimpaTela(Form Formulario)
        {
            //(08/04/2019-Bruno e Adão) Percorre todos os componentes do Formulário
            foreach (Control pnl in Formulario.Controls)
            {
                //(08/04/2019-Bruno e Adão) Perguntar se é um painel e se o nome é  pnl_Detalhes
                if (pnl is Panel && pnl.Name == "pnl_Detalhes")
                {
                    //(08/04/2019-Bruno e Adão) Percorre todos os componentes do Painel Detalhes
                    foreach (Control ctrl1 in pnl.Controls)
                    {
                        //(08/04/2019-Bruno e Adão) Perguntar se é um TextBox
                        if (ctrl1 is TextBox)
                        {
                            ctrl1.Text = "";
                        }

                        if (ctrl1 is MaskedTextBox)
                        {
                            ctrl1.Text = "__/__/____";
                        }

                        if (ctrl1 is CheckBox)
                        {
                            ((CheckBox) ctrl1).Checked = false;
                        }

                    }
                }
            }
        }

        /***********************************************************************
        * NOME:            VerificaBranco       
        * METODO:          Verifica se na tela possui campo vazio 
        *                  Detalhes
        * PARAMETRO:       Nome do Formulário, bool (true ou false)                 
        * DT CRIAÇÃO:        
        * DT ALTERAÇÃO:    
        * ESCRITA POR:     Projeto Integrador (Bruno e Adão)
        **********************************************************************/
        public bool CampoVazio(Form Formulario)
        {
            bool bBranco = false;
            //(08/04/2019-Bruno e Adão) Percorre todos os componentes do Formulário
            foreach (Control pnl in Formulario.Controls)
            {
                //(08/04/2019-Bruno e Adão) Perguntar se é um painel e se o nome é  pnl_Detalhes
                if (pnl is Panel && pnl.Name == "pnl_Detalhes")
                {
                    //(08/04/2019-Bruno e Adão) Percorre todos os componentes do Painel Detalhes
                    foreach (Control ctrl1 in pnl.Controls)
                    {
                        //(08/04/2019-Bruno e Adão) Perguntar se é um TextBox
                        if (ctrl1 is TextBox)
                        {
                            if (ctrl1.Text == "" && Convert.ToInt16(ctrl1.Tag) != 1)
                                bBranco = true;
                        }

                        if (ctrl1 is MaskedTextBox)
                        {
                            if (ctrl1.Text == "__/__/____")
                                bBranco = true;
                        }
                    }
                }

            }
            return bBranco;
        }

        /***********************************************************************
        * NOME:            HabilitaTela       
        * METODO:          Habilita cada Componente editável que está no painel 
        *                  Detalhes
        * PARAMETRO:       Nome do Formulário, bool (true ou false)                 
        * DT CRIAÇÃO:      08/04/2019    
        * DT ALTERAÇÃO:    22/04/2019
        * ESCRITA POR:     Projeto Integrador (Bruno e Adão)
        **********************************************************************/
        public void HabilitaTela(Form Formulario, bool bHab)
        {
            //(08/04/2019-Bruno e Adão) Percorre todos os componentes do Formulário
            foreach (Control pnl in Formulario.Controls)
            {
                //(08/04/2019-Bruno e Adão) Perguntar se é um painel e se o nome é  pnl_Detalhes
                if (pnl is Panel && pnl.Name == "pnl_Detalhes")
                {
                    //(08/04/2019-Bruno e Adão) Percorre todos os componentes do Painel Detalhes
                    foreach (Control ctrl1 in pnl.Controls)
                    {
                        //(08/04/2019-Bruno e Adão) Perguntar se é um TextBox
                        if (ctrl1 is TextBox && Convert.ToInt16(ctrl1.Tag) != 1)
                        {
                            ctrl1.Enabled = bHab;
                        }

                        if (ctrl1 is MaskedTextBox)
                        {
                            ctrl1.Enabled = bHab;
                        }

                        if (ctrl1 is CheckBox)
                        {
                            ctrl1.Enabled = bHab;
                        }
                    }
                }
            }
        }


        /***********************************************************************
        * NOME:            StatusBtn       
        * METODO:          Definir o Status dos botões da tela no painel botões
        * PARAMETRO:       Nome do Formulário, status (int)                 
        * DT CRIAÇÃO:      08/04/2019    
        * DT ALTERAÇÃO:    22/04/2019
        * ESCRITA POR:     Projeto Integrador (Bruno e Adão)
        **********************************************************************/
        public void StatusBtn(Form Formulario, int iStatus)
        {

            switch (iStatus)
            {
                case 0:
                {
                    //(08/04/2019-Bruno e Adão) Percorre todos os componentes do Formulário
                    foreach (Control pnl in Formulario.Controls)
                    {
                        //(08/04/2019-Bruno e Adão) Perguntar se é um painel e se o nome é  pnl_Detalhes
                        if (pnl is Panel && pnl.Name == "pnl_Botoes")
                        {
                            //(08/04/2019-Bruno e Adão) Percorre todos os componentes do Painel Detalhes
                            foreach (Control ctrl1 in pnl.Controls)
                            {
                                //(08/04/2019-Bruno e Adão) Perguntar se é o btn novo
                                if (ctrl1 is Button && ctrl1.Name == "btn_Novo")
                                {
                                    ctrl1.Enabled = true;
                                }
                                //(08/04/2019-Bruno e Adão) Perguntar se é o btn alterar
                                if (ctrl1 is Button && ctrl1.Name == "btn_Alterar")
                                {
                                    ctrl1.Enabled = false;
                                }
                                //(08/04/2019-Bruno e Adão) Perguntar se é o btn excluir
                                if (ctrl1 is Button && ctrl1.Name == "btn_Excluir")
                                {
                                    ctrl1.Enabled = false;
                                }

                                //(08/04/2019-Bruno e Adão) Perguntar se é o btn confirmar
                                if (ctrl1 is Button && ctrl1.Name == "btn_Confirmar")
                                {
                                    ctrl1.Enabled = false;
                                }
                                //(08/04/2019-Bruno e Adão) Perguntar se é o btn cancelar
                                if (ctrl1 is Button && ctrl1.Name == "btn_Cancelar")
                                {
                                    ctrl1.Enabled = false;
                                }
                            }
                        }
                    }
                    break;
                }

                case 1:
                {
                    //(08/04/2019-Bruno e Adão) Percorre todos os componentes do Formulário
                    foreach (Control pnl in Formulario.Controls)
                    {
                        //(08/04/2019-Bruno e Adão) Perguntar se é um painel e se o nome é  pnl_Detalhes
                        if (pnl is Panel && pnl.Name == "pnl_Botoes")
                        {
                            //(08/04/2019-Bruno e Adão) Percorre todos os componentes do Painel Detalhes
                            foreach (Control ctrl1 in pnl.Controls)
                            {
                                //(08/04/2019-Bruno e Adão) Perguntar se é o btn novo
                                if (ctrl1 is Button && ctrl1.Name == "btn_Novo")
                                {
                                    ctrl1.Enabled = true;
                                }
                                //(08/04/2019-Bruno e Adão) Perguntar se é o btn alterar
                                if (ctrl1 is Button && ctrl1.Name == "btn_Alterar")
                                {
                                    ctrl1.Enabled = true;
                                }
                                //(08/04/2019-Bruno e Adão) Perguntar se é o btn excluir
                                if (ctrl1 is Button && ctrl1.Name == "btn_Excluir")
                                {
                                    ctrl1.Enabled = true;
                                }

                                //(08/04/2019-Bruno e Adão) Perguntar se é o btn confirmar
                                if (ctrl1 is Button && ctrl1.Name == "btn_Confirmar")
                                {
                                    ctrl1.Enabled = false;
                                }
                                //(08/04/2019-Bruno e Adão) Perguntar se é o btn cancelar
                                if (ctrl1 is Button && ctrl1.Name == "btn_Cancelar")
                                {
                                    ctrl1.Enabled = false;
                                }
                            }
                        }
                    }
                    break;
                }

                case 2:
                {
                    //(08/04/2019-Bruno e Adão) Percorre todos os componentes do Formulário
                    foreach (Control pnl in Formulario.Controls)
                    {
                        //(08/04/2019-Bruno e Adão) Perguntar se é um painel e se o nome é  pnl_Detalhes
                        if (pnl is Panel && pnl.Name == "pnl_Botoes")
                        {
                            //(08/04/2019-Bruno e Adão) Percorre todos os componentes do Painel Detalhes
                            foreach (Control ctrl1 in pnl.Controls)
                            {
                                //(08/04/2019-Bruno e Adão) Perguntar se é o btn novo
                                if (ctrl1 is Button && ctrl1.Name == "btn_Novo")
                                {
                                    ctrl1.Enabled = false;
                                }
                                //(08/04/2019-Bruno e Adão) Perguntar se é o btn alterar
                                if (ctrl1 is Button && ctrl1.Name == "btn_Alterar")
                                {
                                    ctrl1.Enabled = false;
                                }
                                //(08/04/2019-Bruno e Adão) Perguntar se é o btn excluir
                                if (ctrl1 is Button && ctrl1.Name == "btn_Excluir")
                                {
                                    ctrl1.Enabled = false;
                                }

                                //(08/04/2019-Bruno e Adão) Perguntar se é o btn confirmar
                                if (ctrl1 is Button && ctrl1.Name == "btn_Confirmar")
                                {
                                    ctrl1.Enabled = true;
                                }
                                //(08/04/2019-Bruno e Adão) Perguntar se é o btn cancelar
                                if (ctrl1 is Button && ctrl1.Name == "btn_Cancelar")
                                {
                                    ctrl1.Enabled = true;
                                }
                            }
                        }
                    }
                    break;
                }

            }
        }
    }
}

                    