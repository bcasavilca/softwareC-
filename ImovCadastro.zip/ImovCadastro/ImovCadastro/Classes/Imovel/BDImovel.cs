﻿/**********************************************************************************
 * NOME:            BDImovel
 * CLASSE:          Representação da classe Imovel que conecta com o 
 *                  banco de dados
 * DT CRIAÇÃO:      08/04/2019    
 * DT ALTERAÇÃO:    29/04/2019
 * ESCRITA POR:     Projeto Integrador (Bruno e Adão)    
 * ********************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.IO;
using System.Dynamic;
using System.Windows.Forms;



namespace ImovCadastro
{
    class BDImovel
    {
        /***********************************************************************
        * NOME          :  Incluir          
        * METODO        :  Responsável por incluir o Objeto na Base de Dados.
        *                  Inclui um registro na tabela tb_Imovel.         
        * DT CRIAÇÃO:      08/04/2019    
        * DT ALTERAÇÃO:    29/04/2019
        * ESCRITA POR:     Projeto Integrador (Bruno e Adão) 
        * OBSERVAÇÕES   :  Utiliza a Classe Connection para acessar o BD.   
        **********************************************************************/
        public int Incluir(Imovel aobjImovel)
        {
            //(08/04/2019-Bruno e Adão) Cria objeto para a conexão com o banco de dados
            SqlConnection objCon = new SqlConnection(Connection.ConnectionPath());

            string varSql = "INSERT INTO tb_Imovel" +
                        "(" +
                        " icodProprietario, " +
                        " sendImovel, " +
                        " sbaiImovel, " +
                        " sufImovel, " +
                        " scepImovel, " +
                        " dtcadImovel" +
                        ")" +         
                        " VALUES" +   
                        "(" +
                        " @icodProprietario, " +
                        " @sendImovel, " +
                        " @sbaiImovel, " +
                        " @sufImovel, " +
                        " @scepImovel, " +
                        " @dtcadImovel" +
                        "); " +
                        "SELECT ident_current('tb_Imovel') as 'id'";

            SqlCommand objCmd = new SqlCommand(varSql, objCon);
            objCmd.Parameters.AddWithValue("@icodProprietario", aobjImovel.codProprietario);
            objCmd.Parameters.AddWithValue("@sendImovel", aobjImovel.endImovel);
            objCmd.Parameters.AddWithValue("@sbaiImovel", aobjImovel.baiImovel);
            objCmd.Parameters.AddWithValue("@sufImovel", aobjImovel.ufImovel);
            objCmd.Parameters.AddWithValue("@scepImovel", aobjImovel.cepImovel);
            objCmd.Parameters.AddWithValue("@dtcadImovel", aobjImovel.dtcadImovel.Date);

            try
            {

                objCon.Open();
                int _id = Convert.ToInt16(objCmd.ExecuteScalar());
                objCon.Close();

                return _id;
            }
            catch (Exception erro)
            {
                MessageBox.Show(erro.Message, "ERRO FATAL", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
        }

        /***********************************************************************
         * NOME          :  Alterar          
         * METODO        :  Responsável por Editar o Objeto na Base de Dados.
         *                  Altera um registro na tabela tb_Imovel.         
         * DT CRIAÇÃO:      08/04/2019    
         * DT ALTERAÇÃO:    29/04/2019
         * ESCRITA POR:     Projeto Integrador (Bruno e Adão) 
         * OBSERVAÇÕES   :  Utiliza a Classe Connection para acessar o BD.   
         **********************************************************************/
        public bool Alterar(Imovel aobjImovel)
        {
            if (aobjImovel.codImovel != -1)
            {
                //(08/04/2019-Bruno e Adão) Cria objeto para a conexão com o banco de dados
                SqlConnection objCon = new SqlConnection(Connection.ConnectionPath());

                string varSql = " UPDATE tb_Imovel SET " +
                " icodProprietario = @icodProprietario," +
                " sendImovel = @sendImovel," +
                " sbaiImovel = @sbaiImovel," +
                " sufImovel = @sufImovel," +
                " scepImovel = @scepImovel," +
                " dtcadImovel = @dtcadImovel" +
                " WHERE icodImovel = @icodImovel ";

                SqlCommand objCmd = new SqlCommand(varSql, objCon);
                objCmd.Parameters.AddWithValue("@icodProprietario", aobjImovel.codProprietario);
                objCmd.Parameters.AddWithValue("@sendImovel",aobjImovel.endImovel);
                objCmd.Parameters.AddWithValue("@sbaiImovel",aobjImovel.baiImovel);
                objCmd.Parameters.AddWithValue("@sufImovel",aobjImovel.ufImovel);
                objCmd.Parameters.AddWithValue("@scepImovel",aobjImovel.cepImovel);
                objCmd.Parameters.AddWithValue("@dtcadImovel",aobjImovel.dtcadImovel.Date);


                try
                {

                    objCon.Open();
                    objCmd.ExecuteNonQuery();
                    objCon.Close();

                    return true;
                }
                catch (Exception erro)
                {
                    MessageBox.Show(erro.Message, "ERRO FATAL", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

            }
            else
            {
                return false;
            }
        }

        /***********************************************************************
        * NOME          :  Excluir          
        * METODO        :  Responsável por excluir o Objeto na Base de Dados.
        *                  Deleta um registro na tabela tb_Imovel.         
        * DT CRIAÇÃO:      08/04/2019    
        * DT ALTERAÇÃO:    29/04/2019
        * ESCRITA POR:     Projeto Integrador (Bruno e Adão)
        * OBSERVAÇÕES   :  Utiliza a Classe Connection para acessar o BD.   
        **********************************************************************/
        public bool Excluir(Imovel aobjImovel)
        {
            SqlConnection objCon = new SqlConnection(Connection.ConnectionPath());

            //(08/04/2019-Bruno e Adão) Cria a variável que conterá o comando SQL
            string varSql = "DELETE FROM tb_Imovel WHERE icodImovel = @icodImovel";

            //(08/04/2019-Bruno e Adão) Cria o objeto que executa o comando
            SqlCommand objCmd = new SqlCommand(varSql, objCon);
            objCmd.Parameters.AddWithValue("@icodImovel", aobjImovel.codImovel);

            try
            {
                objCon.Open();
                objCmd.ExecuteNonQuery();
                objCon.Close();

                return true;
            }
            catch (Exception erro)
            {
                MessageBox.Show(erro.Message, "ERRO FATAL", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        /***********************************************************************
        * NOME          :  FindByImovel       
        * METODO        :  Responsável por encontrar o Objeto na Base de Dados.
        *                  Busca um registro na tabela tb_Imovel.         
        * DT CRIAÇÃO:      08/04/2019    
        * DT ALTERAÇÃO:    29/04/2019
        * ESCRITA POR:     Projeto Integrador (Bruno e Adão)
        * OBSERVAÇÕES   :  Utiliza a Classe Connection para acessar o BD.   
        **********************************************************************/
        public Imovel FindByImovel(Imovel aobjImovel)
        {
            //(08/04/2019-Bruno e Adão) Cria objeto para a conexão com o banco de dados
            SqlConnection objCon = new SqlConnection(Connection.ConnectionPath());

            //(08/04/2019-Bruno e Adão) Cria a variável que conterá o comando SQL
            string varSql = "SELECT * FROM tb_Imovel WHERE icodImovel = @icodImovel";

            //(08/04/2019-Bruno e Adão) Cria o objeto que executa o comando
            SqlCommand objCmd = new SqlCommand(varSql, objCon);
            objCmd.Parameters.AddWithValue("@icodImovel", aobjImovel.codImovel);

            //(08/04/2019-Bruno e Adão) Abre a conexão com o banco de dados
            objCon.Open();

            //(08/04/2019-Bruno e Adão) Executa o comando para excluir o registro
            SqlDataReader objDtr = objCmd.ExecuteReader();

            //(08/04/2019-Bruno e Adão) Pergunta se existe linha no Reader
            if (objDtr.HasRows)
            {
                //(08/04/2019-Bruno e Adão) Lê os dados que estão no objDtr
                objDtr.Read();

                //(08/04/2019-Bruno e Adão) Coloca os dados do Reader no Objeto
                aobjImovel.codImovel=Convert.ToInt16(objDtr["icodImovel"]);
                aobjImovel.codProprietario = Convert.ToInt16(objDtr["icodProprietario"]);
                aobjImovel.endImovel=objDtr["sendImovel"].ToString();
                aobjImovel.baiImovel=objDtr["sbaiImovel"].ToString();
                aobjImovel.ufImovel=objDtr["sufImovel"].ToString();
                aobjImovel.cepImovel=objDtr["scepImovel"].ToString();
                aobjImovel.dtcadImovel=Convert.ToDateTime(objDtr["dtcadImovel"]);


                //(08/04/2019-Bruno e Adão) Fecha a conexão com o banco de dados
                objCon.Close();

                //(08/04/2019-Bruno e Adão) Fecha o objeto Reader
                objDtr.Close();

                return aobjImovel;
            }
            else
            {
                //(08/04/2019-Bruno e Adão) Fecha a conexão com o banco de dados
                objCon.Close();

                //(08/04/2019-Bruno e Adão) Fecha o objeto Reader
                objDtr.Close();

                return null;
            }
        }

        /***********************************************************************
        * NOME          :  FindAllImovel       
        * METODO        :  Responsável por encontrar todos os Objetos na Base 
        *                  de Dados. Busca todos os registros na tabela tb_Imovel.         
        * DT CRIAÇÃO:      08/04/2019    
        * DT ALTERAÇÃO:    29/04/2019
        * ESCRITA POR:     Projeto Integrador (Bruno e Adão) 
        * OBSERVAÇÕES   :  Utiliza a Classe Connection para acessar o BD.   
        **********************************************************************/
        public List<Imovel> FindAllImovel()
        {
            //(08/04/2019-Bruno e Adão) Cria objeto para a conexão com o banco de dados
            SqlConnection objCon = new SqlConnection(Connection.ConnectionPath());

            //(08/04/2019-Bruno e Adão) Cria a variável que conterá o comando SQL
            string varSql = "SELECT * FROM tb_Imovel";

            //(08/04/2019-Bruno e Adão) Cria o objeto que executa o comando
            SqlCommand objCmd = new SqlCommand(varSql, objCon);

            //(08/04/2019-Bruno e Adão) Abre a conexão com o banco de dados
            objCon.Open();

            //(08/04/2019-Bruno e Adão) Executa o comando para excluir o registro
            SqlDataReader objDtr = objCmd.ExecuteReader();

            List<Imovel> lista = new List<Imovel>();

            if (objDtr.HasRows)
            {
                //(08/04/2019-Bruno e Adão) Enquanto tiver linha faça
                while (objDtr.Read())
                {
                    //(08/04/2019-Bruno e Adão) Instância do objto Receita
                    Imovel aobjImovel = new Imovel();

                    //(08/04/2019-Bruno e Adão) Coloca os dados do Reader no Objeto
                    aobjImovel.codImovel=Convert.ToInt16(objDtr["icodImovel"]);
                    aobjImovel.codProprietario = Convert.ToInt16(objDtr["icodProprietario"]);
                    aobjImovel.endImovel=objDtr["sendImovel"].ToString();
                    aobjImovel.baiImovel=objDtr["sbaiImovel"].ToString();
                    aobjImovel.ufImovel=objDtr["sufImovel"].ToString();
                    aobjImovel.cepImovel=objDtr["scepImovel"].ToString();
                    aobjImovel.dtcadImovel=Convert.ToDateTime(objDtr["dtcadImovel"]);



                    lista.Add(aobjImovel);
                }
                //(08/04/2019-Bruno e Adão) Fecha a conexão com o banco de dados
                objCon.Close();

                //(08/04/2019-Bruno e Adão) Fecha o objeto Reader
                objDtr.Close();

                return lista;
            }
            else
            {
                //(08/04/2019-Bruno e Adão) Fecha a conexão com o banco de dados
                objCon.Close();

                //(08/04/2019-Bruno e Adão) Fecha o objeto Reader
                objDtr.Close();

                return null;
            }

        }

    }
}

