﻿/**********************************************************************************
 * NOME:            Proprietario
 * CLASSE:          Representação do objeto Proprietario
 * DT CRIAÇÃO:      08/04/2019    
 * DT ALTERAÇÃO:    29/04/2019
 * ESCRITA POR:     Projeto Integrador (Bruno e Adão)
 * OBSERVAÇÕES:     Atributos privados com métodos Get e Set públicos
 * ********************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImovCadastro
{
    public class Imovel
    {
        //Destructor da Classe
        ~Imovel()
        {
        }

        //Atributos/Propriedades Privadas Encapsuladas
        private int vcodImovel = -1;
        private int vcodProprietario = -1;
        private string vendImovel = "";
        private string vbaiImovel = "";
        private string vufImovel = "";
        private string vnmImovel = "";
        private string vcepImovel = "";
        private DateTime vdtcadImovel = DateTime.MinValue;

        //Metodos/Ações Publicas

        /***********************************************************************
         * NOME:            codImovel         
         * METODO:          Representação do atributo Código com os métodos 
         *                  Get e Set          
         * DT CRIAÇÃO:      08/04/2019       
         * DT ALTERAÇÃO:    29/04/2019
         * ESCRITA POR:     Projeto Integrador (Bruno e Adão)
         **********************************************************************/
        public int codImovel
        {
            get { return vcodImovel; }
            set { vcodImovel = value; }
        }

        /***********************************************************************
         * NOME:            codProprietario
         * METODO:          Representação do atributo Código do proprietario com os métodos 
         *                  Get e Set          
         * DT CRIAÇÃO:      08/04/2019      
         * DT ALTERAÇÃO:    29/04/2019
         * ESCRITA POR:     Projeto Integrador (Bruno e Adão)
         **********************************************************************/
        public int codProprietario
        {
            get { return vcodProprietario; }
            set { vcodProprietario = value; }
        }




        /***********************************************************************
        * NOME:            endImovel
        * METODO:          Representação do atributo enderesso do Proprietario com os
        *                  métodos Get e Set          
        * DT CRIAÇÃO:      08/04/2019    
        * DT ALTERAÇÃO:    29/04/2019
        * ESCRITA POR:     Projeto Integrador (Bruno e Adão)
        **********************************************************************/
        public string endImovel
        {
            get { return vendImovel; }
            set { vendImovel = value; }
        }

        /***********************************************************************
         * NOME:            baiImovel
         * METODO:          Representação do atributo bairro do imovel com os
         *                  métodos Get e Set          
         * DT CRIAÇÃO:      08/04/2019    
         * DT ALTERAÇÃO:    29/04/2019
         * ESCRITA POR:     Projeto Integrador (Bruno e Adão)
         **********************************************************************/
        public string baiImovel
        {
            get { return vbaiImovel; }
            set { vbaiImovel = value; }
        }

        /***********************************************************************
       * NOME:            ufImovel
       * METODO:          Representação do atributo estado do Proprietario com os
       *                  métodos Get e Set          
       * DT CRIAÇÃO:      08/04/2019    
       * DT ALTERAÇÃO:    29/04/2019
       * ESCRITA POR:     Projeto Integrador (Bruno e Adão)
       **********************************************************************/
        public string ufImovel
        {
            get { return vufImovel; }
            set { vufImovel = value; }
        }

        /***********************************************************************
      * NOME:            cepImovel
      * METODO:          Representação do atributo nm do Imovel com os
      *                  métodos Get e Set          
      * DT CRIAÇÃO:      08/04/2019    
      * DT ALTERAÇÃO:    29/04/2019
      * ESCRITA POR:     Projeto Integrador (Bruno e Adão)
      **********************************************************************/
        public string cepImovel
        {
            get { return vcepImovel; }
            set { vcepImovel = value; }
        }
        /***********************************************************************
        * NOME:            nmProprietario
        * METODO:          Representação do atributo nm do Proprietario com os
        *                  métodos Get e Set          
        * DT CRIAÇÃO:      08/04/2019    
        * DT ALTERAÇÃO:    29/04/2019
        * ESCRITA POR:     Projeto Integrador (Bruno e Adão)
        **********************************************************************/
        public string nmImovel
        {
            get { return vnmImovel; }
            set { vnmImovel = value; }
        }

        /***********************************************************************
       * NOME:            vdtcadImovel
       * METODO:          Representação do atributo a data do cadastro do imovel com os
       *                  métodos Get e Set          
       * DT CRIAÇÃO:      08/04/2019    
       * DT ALTERAÇÃO:    29/04/2019
       * ESCRITA POR:     Projeto Integrador (Bruno e Adão)
       **********************************************************************/
        public DateTime dtcadImovel
        {
            get { return vdtcadImovel; }
            set { vdtcadImovel = value; }
        }
    }
}
